# Beamer-xxxii-semana-unison-2022-AppliedMathWorkshop

Maximum likelihood estimation for a stochastic SEIR system
an application of the Grisanov's Theorem for the likelihood ratio
March 28, 2022
# Beamer-xxxii-semana-unison-2022-AppliedMathWorkshop
